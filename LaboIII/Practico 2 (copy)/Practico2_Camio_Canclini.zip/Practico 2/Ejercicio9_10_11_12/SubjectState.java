package Ejercicio9_10_11_12;

public enum SubjectState {
    APROBADA,
    CURSADA
}
